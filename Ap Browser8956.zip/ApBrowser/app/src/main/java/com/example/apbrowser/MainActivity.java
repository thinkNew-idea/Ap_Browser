package com.example.apbrowser;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.util.Pair;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.Activity;
import android.app.DownloadManager;
import android.app.TabActivity;
import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebChromeClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.example.apbrowser.Model.Article;
import com.example.apbrowser.Model.News;
import com.example.apbrowser.api.ApiClient;
import com.example.apbrowser.api.ApiInterface;
import com.example.apbrowser.api.Utils;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.zip.Inflater;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity  implements AdapterView.OnItemSelectedListener , SwipeRefreshLayout.OnRefreshListener{
    ImageView goole, face,instagram,yohoo,youtube,whatsapp,tweet,game,searchclick;
    EditText e1;
    String[] searchtype={"Google","Yahoo"};
    int flags[] = {R.drawable.google, R.drawable.yahoo,};
    public static final String API_KEY = "f54e35603269414e9a0da522ec33cd69";
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private List<Article> articles = new ArrayList<>();
    private Adapter adapter;
    private String TAG = MainActivity.class.getSimpleName();
    private SwipeRefreshLayout swipeRefreshLayout;
    private RelativeLayout errorLayout;
    private ImageView errorImage;
    private TextView errorTitle, errorMessage;
    private Button btnRetry;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        goole = findViewById(R.id.google);
        face = findViewById(R.id.facebook);
        instagram = findViewById(R.id.instagram);
        yohoo = findViewById(R.id.yohoo);
        youtube = findViewById(R.id.youtube);
        whatsapp = findViewById(R.id.whatsapp);
        tweet = findViewById(R.id.tweet);
        game = findViewById(R.id.game);
        e1 = findViewById(R.id.search);
        searchclick = findViewById(R.id.searchclick);
        Spinner spin = (Spinner) findViewById(R.id.searchspinner);
        CustomAdapter customAdapter=new CustomAdapter(getApplicationContext(),flags,searchtype);
        spin.setAdapter((SpinnerAdapter) customAdapter);
        spin.setOnItemSelectedListener(this);
        swipeRefreshLayout = findViewById(R.id.swipe_refresh_layout);
        swipeRefreshLayout.setOnRefreshListener(this);
        swipeRefreshLayout.setColorSchemeResources(R.color.colorAccent);
        recyclerView = findViewById(R.id.recyclerViewone);
        layoutManager = new LinearLayoutManager(MainActivity.this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setNestedScrollingEnabled(false);

        onLoadingSwipeRefresh("");

        errorLayout = findViewById(R.id.errorLayout);
        errorImage = findViewById(R.id.errorImage);
        errorTitle = findViewById(R.id.errorTitle);
        errorMessage = findViewById(R.id.errorMessage);
        btnRetry = findViewById(R.id.btnRetry);


        goole.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a = "https://www.google.com";
                String query="Google";
                Intent i = new Intent(MainActivity.this, Webviews.class);
                i.putExtra("ur", a);
                i.putExtra("query",query);
                startActivity(i);
            }
        });

        face.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String b = "https://www.facebook.com";
                String query="Facebook";
                Intent i = new Intent(MainActivity.this, Webviews.class);
                i.putExtra("ur", b);
                i.putExtra("query",query);
                startActivity(i);
            }
        });
        instagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String b = "https://www.instagram.com";
                String query="Instagram";
                Intent i = new Intent(MainActivity.this, Webviews.class);
                i.putExtra("ur", b);
                i.putExtra("query",query);
                startActivity(i);
            }
        });
        yohoo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String b = "https://in.yahoo.com";
                String query="Yahoo";
                Intent i = new Intent(MainActivity.this, Webviews.class);
                i.putExtra("ur", b);
                i.putExtra("query",query);
                startActivity(i);
            }
        });
        youtube.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String b = "https://www.youtube.com";
                String query="Youtube";
                Intent i = new Intent(MainActivity.this, Webviews.class);
                i.putExtra("ur", b);
                i.putExtra("query",query);
                startActivity(i);
            }
        });
        tweet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String b = "https://twitter.com";
                String query="Twitter";
                Intent i = new Intent(MainActivity.this, Webviews.class);
                i.putExtra("ur", b);
                i.putExtra("query",query);
                startActivity(i);
            }
        });
        game.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intenta = new Intent(MainActivity.this, free_game.class);
                startActivity(intenta);
                overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
            }
        });
        whatsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String b = "https://www.whatsapp.com";
                String query="Whatsapp";
                Intent i = new Intent(MainActivity.this, Webviews.class);
                i.putExtra("ur", b);
                i.putExtra("query",query);
                startActivity(i);
            }
        });


        bottomNavigationView.clearAnimation();
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.action_settings:
                        Intent setting = new Intent(getApplicationContext(), setting_page.class);
                        startActivity(setting);
                        overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
                        break;
                    case R.id.backword:
                        menuItem.setCheckable(false);
                      Toast.makeText(getApplicationContext(),"Nothing is to back",Toast.LENGTH_LONG).show();
                        break;
                    case R.id.action_home:
                        Intent home = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(home);
                        overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
                        break;
                    case R.id.action_download:
                        Intent i=new Intent();
                        i.setAction(DownloadManager.ACTION_VIEW_DOWNLOADS);
                        startActivity(i);
                        overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
                        break;
                    case R.id.forword:
                        menuItem.setCheckable(false);
                        Toast.makeText(getApplicationContext(),"Nothing is to Forword",Toast.LENGTH_LONG).show();
                        break;

                }
                return false;
            }
        });

    }
    public void LoadJson(final String keyword){

        errorLayout.setVisibility(View.GONE);
        swipeRefreshLayout.setRefreshing(true);

        ApiInterface apiInterface = ApiClient.getApiClient().create(ApiInterface.class);

        String country = Utils.getCountry();
        String language = Utils.getLanguage();

        Call<News> call;

        if (keyword.length() > 0 ){
            call = apiInterface.getNewsSearch(keyword, language, "publishedAt", API_KEY);
        } else {
            call = apiInterface.getNews(country, API_KEY);
        }

        call.enqueue(new Callback<News>() {
            @Override
            public void onResponse(Call<News> call, Response<News> response) {
                if (response.isSuccessful() && response.body().getArticle() != null){

                    if (!articles.isEmpty()){
                        articles.clear();
                    }

                    articles = response.body().getArticle();
                    adapter = new Adapter(articles, MainActivity.this);
                    recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();

                    initListener();

                    swipeRefreshLayout.setRefreshing(false);


                } else {

                    swipeRefreshLayout.setRefreshing(false);

                    String errorCode;
                    switch (response.code()) {
                        case 404:
                            errorCode = "404 not found";
                            break;
                        case 500:
                            errorCode = "500 server broken";
                            break;
                        default:
                            errorCode = "unknown error";
                            break;
                    }

                    showErrorMessage(
                            R.drawable.no_result,
                            "No Result",
                            "Please Try Again!\n"+
                                    errorCode);

                }
            }

            @Override
            public void onFailure(Call<News> call, Throwable t) {
                swipeRefreshLayout.setRefreshing(false);
                showErrorMessage(
                        R.drawable.oops,
                        "Oops..",
                        "Network failure, Please Try Again\n"+
                                t.toString());
            }
        });

    }



    private void initListener(){

        adapter.setOnItemClickListener(new Adapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                ImageView imageView = view.findViewById(R.id.img);
                Intent intent = new Intent(MainActivity.this, NewsShow.class);

                Article article = articles.get(position);
                intent.putExtra("url", article.getUrl());
                intent.putExtra("title", article.getTitle());
                intent.putExtra("img",  article.getUrlToImage());
                intent.putExtra("date",  article.getPublishedAt());
                intent.putExtra("source",  article.getSource().getName());
                intent.putExtra("author",  article.getAuthor());

                Pair<View, String> pair = Pair.create((View)imageView, ViewCompat.getTransitionName(imageView));
                ActivityOptionsCompat optionsCompat = ActivityOptionsCompat.makeSceneTransitionAnimation(MainActivity.this, pair);


                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    startActivity(intent, optionsCompat.toBundle());
                }else {
                    startActivity(intent);
                }

            }
        });

    }
    @Override
    public void onRefresh() {
        LoadJson("");
    }

    private void onLoadingSwipeRefresh(final String keyword){

        swipeRefreshLayout.post(
                new Runnable() {
                    @Override
                    public void run() {
                        LoadJson(keyword);
                    }
                }
        );

    }

    private void showErrorMessage(int imageView, String title, String message){

        if (errorLayout.getVisibility() == View.GONE) {
            errorLayout.setVisibility(View.VISIBLE);
        }

        errorImage.setImageResource(imageView);
        errorTitle.setText(title);
        errorMessage.setText(message);

        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onLoadingSwipeRefresh("");
            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
       if (searchtype[position].equals("Google")){
         searchclick.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   String query = e1.getText().toString();
                   String ur = "https://www.google.com/search?q=" + query;
                   Intent i = new Intent(MainActivity.this, Webviews.class);
                   i.putExtra("ur", ur);
                   i.putExtra("query",query);
                   startActivity(i);
               }
           });
           e1.setOnKeyListener(new View.OnKeyListener() {
               public boolean onKey(View v, int keyCode, KeyEvent event) {

                   if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                           (keyCode == KeyEvent.KEYCODE_ENTER)) {
                       String query = e1.getText().toString();
                       String ur = "https://www.google.com/search?q=" + query;
                       Intent i = new Intent(MainActivity.this, Webviews.class);
                       i.putExtra("ur", ur);
                       i.putExtra("query",query);
                       startActivity(i);

                       return true;
                   }
                   return false;
               }
           });
       }
       else if (searchtype[position].equals("Yahoo")){
           searchclick.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   String query = e1.getText().toString();
                   String ur = "https://in.search.yahoo.com/search?p=" + query;
                   Intent i = new Intent(MainActivity.this, yahosearchweb.class);
                   i.putExtra("ur", ur);
                   i.putExtra("query",query);
                   startActivity(i);

               }
           });
           e1.setOnKeyListener(new View.OnKeyListener() {
               public boolean onKey(View v, int keyCode, KeyEvent event) {

                   if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                           (keyCode == KeyEvent.KEYCODE_ENTER)) {
                       String query = e1.getText().toString();
                       String ur = "https://in.search.yahoo.com/search?p=" + query;
                       Intent i = new Intent(MainActivity.this, yahosearchweb.class);
                       i.putExtra("ur", ur);
                       i.putExtra("query",query);
                       startActivity(i);

                       return true;
                   }
                   return false;
               }
           });
       }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

        searchclick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String query = e1.getText().toString();
                String ur = "https://www.google.com/search?q=" + query;
                Intent i = new Intent(MainActivity.this, Webviews.class);
                i.putExtra("ur", ur);
                i.putExtra("query",query);
                startActivity(i);

            }
        });
        e1.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    String query = e1.getText().toString();
                    String ur = "https://www.google.com/search?q=" + query;
                    Intent i = new Intent(MainActivity.this, Webviews.class);
                    i.putExtra("ur", ur);
                    i.putExtra("query",query);
                    startActivity(i);
                    return true;
                }
                return false;
            }
        });
    }
}