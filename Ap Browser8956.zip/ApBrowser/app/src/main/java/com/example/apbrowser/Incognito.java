package com.example.apbrowser;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

public class Incognito extends AppCompatActivity {
    ImageView searchclick;
    EditText e1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_incognito);
        e1 = findViewById(R.id.search);
        searchclick = findViewById(R.id.searchclick);

        searchclick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String query = e1.getText().toString();
                String ur = "https://www.google.com/search?q=" + query;
                Intent i = new Intent(Incognito.this, Webviews.class);
                i.putExtra("ur", ur);
                startActivity(i);
            }
        });
        e1.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    String query = e1.getText().toString();
                    String ur = "https://www.google.com/search?q=" + query;
                    Intent i = new Intent(Incognito.this, Webviews.class);
                    i.putExtra("ur", ur);
                    startActivity(i);
                    return true;
                }
                return false;
            }
        });
    }
}