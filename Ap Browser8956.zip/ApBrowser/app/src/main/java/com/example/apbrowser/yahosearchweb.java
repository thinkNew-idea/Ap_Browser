package com.example.apbrowser;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class yahosearchweb extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    EditText e1;
    ImageView searchclick;
    String[] searchtype={"Yahoo","Google"};
    int flags[] = {R.drawable.yahoo,R.drawable.google,};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yahosearchweb);
        e1=findViewById(R.id.search);
        searchclick=findViewById(R.id.searchclick);
        Spinner spin = (Spinner) findViewById(R.id.searchspinner);
        CustomAdapter customAdapter=new CustomAdapter(getApplicationContext(),flags,searchtype);
        spin.setAdapter((SpinnerAdapter) customAdapter);
        spin.setOnItemSelectedListener(this);
        final WebView w= findViewById(R.id.web1);
        w.loadUrl(getIntent().getExtras().getString("ur"));
        w.getSettings().setJavaScriptEnabled(true);
        w.setWebViewClient(new WebViewClient());
        searchclick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String query = e1.getText().toString();
                String url ="https://in.search.yahoo.com/search?p="+query;
                w.loadUrl(url);
                w.getSettings().setJavaScriptEnabled(true);
                w.setWebViewClient(new WebViewClient());
                e1.setText(query);
            }
        });
        e1.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    String query = e1.getText().toString();
                    String url ="https://in.search.yahoo.com/search?p="+query;
                    w.loadUrl(url);
                    w.getSettings().setJavaScriptEnabled(true);
                    w.setWebViewClient(new WebViewClient());
                    e1.setText(query);
                    return true;
                }
                return false;
            }
        });


        final BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        bottomNavigationView.clearAnimation();
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.action_settings:
                        Intent setting = new Intent(getApplicationContext(), setting_page.class);
                        startActivity(setting);
                        overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
                        break;
                    case R.id.backword:
                        if (w.canGoBack()) {
                            w.goBack();
                        } else {
                            Intent home = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(home);
                            overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
                        }
                        break;
                    case R.id.action_home:
                        Intent home = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(home);
                        overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
                        break;
                    case R.id.action_download:
                        Intent i=new Intent();
                        i.setAction(DownloadManager.ACTION_VIEW_DOWNLOADS);
                        startActivity(i);
                        overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
                        break;
                    case R.id.forword:
                        if (w.canGoForward()){
                            w.goForward();
                        }else{
                            Toast.makeText(getApplicationContext(),"Nothing is to Forword",Toast.LENGTH_LONG).show();
                            menuItem.setCheckable(false);
                        }
                        break;
                }
                return false;
            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        final WebView w= findViewById(R.id.web1);
        if (searchtype[position].equals("Google")){
            searchclick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String query = e1.getText().toString();
                    String url ="https://www.google.com/search?q="+query;
                    w.loadUrl(url);
                    w.getSettings().setJavaScriptEnabled(true);
                    w.setWebViewClient(new WebViewClient());
                    e1.setText(query);
                }
            });
            e1.setOnKeyListener(new View.OnKeyListener() {
                public boolean onKey(View v, int keyCode, KeyEvent event) {

                    if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                            (keyCode == KeyEvent.KEYCODE_ENTER)) {
                        String query = e1.getText().toString();
                        String url ="https://www.google.com/search?q="+query;
                        w.loadUrl(url);
                        w.getSettings().setJavaScriptEnabled(true);
                        w.setWebViewClient(new WebViewClient());
                        e1.setText(query);
                    }
                    return false;
                }
            });
        }
        else if (searchtype[position].equals("Yahoo")){
            searchclick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String query = e1.getText().toString();
                    String url ="https://in.search.yahoo.com/search?p="+query;
                    w.loadUrl(url);
                    w.getSettings().setJavaScriptEnabled(true);
                    w.setWebViewClient(new WebViewClient());
                    e1.setText(query);
                }
            });
            e1.setOnKeyListener(new View.OnKeyListener() {
                public boolean onKey(View v, int keyCode, KeyEvent event) {

                    if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                            (keyCode == KeyEvent.KEYCODE_ENTER)) {
                        String query = e1.getText().toString();
                        String url ="https://in.search.yahoo.com/search?p="+query;
                        w.loadUrl(url);
                        w.getSettings().setJavaScriptEnabled(true);
                        w.setWebViewClient(new WebViewClient());
                        e1.setText(query);
                    }
                    return false;
                }
            });
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        final WebView w= findViewById(R.id.web);
        searchclick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String query = e1.getText().toString();
                String url ="https://in.search.yahoo.com/search?p="+query;
                w.loadUrl(url);
                w.getSettings().setJavaScriptEnabled(true);
                w.setWebViewClient(new WebViewClient());
                e1.setText(query);
            }
        });
        e1.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    String query = e1.getText().toString();
                    String url ="https://in.search.yahoo.com/search?p="+query;
                    w.loadUrl(url);
                    w.getSettings().setJavaScriptEnabled(true);
                    w.setWebViewClient(new WebViewClient());
                    e1.setText(query);
                }
                return false;
            }
        });
    }
}