package com.example.apbrowser;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.apbrowser.Model.QRCardModel;
import com.example.apbrowser.Model.QRGeoModel;
import com.example.apbrowser.Model.QRURLModel;
import com.google.zxing.Result;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class Scanner_or extends AppCompatActivity implements ZXingScannerView.ResultHandler {
private ZXingScannerView scannerView;
private TextView txtResult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanner_or);


        scannerView = findViewById(R.id.zxscan);
        txtResult =findViewById(R.id.txt_result);

        Dexter.withActivity(this)
                .withPermission(Manifest.permission.CAMERA)
                .withListener(new PermissionListener() {
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse response) {
                     scannerView.setResultHandler(Scanner_or.this);
                     scannerView.startCamera();
                    }

                    @Override
                    public void onPermissionDenied(PermissionDeniedResponse response) {
                        Toast.makeText(Scanner_or.this,"You must accrpt this permission",Toast.LENGTH_SHORT).show();

                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {

                    }
                })
                .check();



    }
    protected void onDestroy(){

        scannerView.stopCamera();
        super.onDestroy();
    }

    @Override
    public void handleResult(Result rawResult) {



     processRawResult(rawResult.getText());

    }

    private void processRawResult(String text) {
        if(text.startsWith("BEGIN:")){
            String [] tokens= text.split("\n");
            QRCardModel qrCardModel =new QRCardModel();
            for(int i=0; i<tokens.length;i++)
            {
                if (tokens[i].startsWith("BEGIN:"))
                {
                    qrCardModel.setType(tokens[i].substring("BEGIN:".length()));
                }
                else
                if (tokens[i].startsWith("N:"))
                {
                    qrCardModel.setName(tokens[i].substring("N:".length()));
                }
                else
                if (tokens[i].startsWith("ORG:"))
                {
                    qrCardModel.setOrg(tokens[i].substring("ORG:".length()));
                }
                else
                if (tokens[i].startsWith("TEL:"))
                {
                    qrCardModel.setTel(tokens[i].substring("TEL:".length()));
                }
                else
                if (tokens[i].startsWith("URL:"))
                {
                    qrCardModel.setUrl(tokens[i].substring("URL:".length()));
                }
                else
                if (tokens[i].startsWith("EMAIL:"))
                {
                    qrCardModel.setEmail(tokens[i].substring("EMAIL:".length()));
                }

                else
                if (tokens[i].startsWith("ADR:"))
                {
                    qrCardModel.setAddress(tokens[i].substring("ADR:".length()));
                }
                else
                if (tokens[i].startsWith("NOTE:"))
                {
                    qrCardModel.setNote(tokens[i].substring("NOTE:".length()));
                }
                else
                if (tokens[i].startsWith("SUMMARY:"))
                {
                    qrCardModel.setSummery(tokens[i].substring("SUMMARY:".length()));
                }
                else
                if (tokens[i].startsWith("DTSTART:"))
                {
                    qrCardModel.setDtstart(tokens[i].substring("DTSTART:".length()));
                }
                else
                if (tokens[i].startsWith("DTEND:"))
                {
                    qrCardModel.setDtend(tokens[i].substring("DTEND:".length()));
                }

                txtResult.setText(qrCardModel.getType());

            }}
            else if (text.startsWith("http://") || text.startsWith("https://") || text.startsWith("www.")){

            QRURLModel qrurlModel =new QRURLModel(text);
            txtResult.setText(qrurlModel.getUrl() );

            }
            else
                if (text.startsWith("geo:"))
                {
                    QRGeoModel qrGeoModel = new QRGeoModel();

                    String delims="[ , ?q= ]+";
                    String tokens[] = text.split(delims);

                    for (int i=0; i<tokens.length;i++){
                        if (tokens[i].startsWith("geo:")){
                            qrGeoModel.setLat(tokens[i] .substring("geo:".length()));
                        }
                    }
                    qrGeoModel.setLat(tokens[0].substring("geo:".length()));
                    qrGeoModel.setLat(tokens[1]);
                    qrGeoModel.setGeo_place(tokens[2]);
                    txtResult.setText(qrGeoModel.getLat()+"/"+qrGeoModel.getLng());
        }
                else
                    {
                        txtResult.setText(text);

                }
        scannerView.resumeCameraPreview(Scanner_or.this);
    }
}