package com.example.apbrowser;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;


public class Webviews extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    EditText e1;
    ImageView searchclick;
    String[] searchtype={"Google","Yahoo"};
    int flags[] = {R.drawable.google, R.drawable.yahoo,};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webviews);
        e1=findViewById(R.id.search);
        searchclick=findViewById(R.id.searchclick);
        Spinner spin = (Spinner) findViewById(R.id.searchspinner);
        CustomAdapter customAdapter=new CustomAdapter(getApplicationContext(),flags,searchtype);
        spin.setAdapter((SpinnerAdapter) customAdapter);
        spin.setOnItemSelectedListener(this);
        final WebView w= findViewById(R.id.web);
        w.loadUrl(getIntent().getExtras().getString("ur"));
        w.getSettings().setJavaScriptEnabled(true);
        w.setWebViewClient(new WebViewClient());
        e1.setText(getIntent().getExtras().getString("ur"));
        searchclick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String query = e1.getText().toString();
                String url ="https://www.google.com/search?q="+query;
                w.loadUrl(url);
                w.getSettings().setJavaScriptEnabled(true);
                w.setWebViewClient(new WebViewClient());
                e1.setText(getIntent().getExtras().getString("query"));
            }
        });
        e1.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    String query = e1.getText().toString();
                    String url ="https://www.google.com/search?q="+query;
                    w.loadUrl(url);
                    w.getSettings().setJavaScriptEnabled(true);
                    w.setWebViewClient(new WebViewClient());
                    e1.setText(query);
                    return true;
                }
                return false;
            }
        });


        final BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        bottomNavigationView.clearAnimation();
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.action_settings:
                        Intent setting = new Intent(getApplicationContext(), setting_page.class);
                        startActivity(setting);
                        overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
                        break;
                    case R.id.backword:
                        if (w.canGoBack()) {
                            w.goBack();
                        } else {
                            Toast.makeText(getApplicationContext(),"Nothing is to back",Toast.LENGTH_LONG).show();
                            menuItem.setCheckable(false);
                        }
                        break;
                    case R.id.action_home:
                        Intent home = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(home);
                        overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
                        break;
                    case R.id.action_download:
                        Intent i=new Intent();
                        i.setAction(DownloadManager.ACTION_VIEW_DOWNLOADS);
                        startActivity(i);
                        overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
                        break;
                    case R.id.forword:
                        if (w.canGoForward()){
                            w.goForward();
                        }else{
                            Toast.makeText(getApplicationContext(),"Nothing is to Forword",Toast.LENGTH_LONG).show();
                            menuItem.setCheckable(false);
                        }
                        break;
                }
                return false;
            }
        });
        }

        public void downloadurl(){
            final WebView w= findViewById(R.id.web);
            w.setDownloadListener(new DownloadListener() {
                @Override
                public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                    DownloadManager.Request request = new DownloadManager.Request(
                            Uri.parse(url));
                    request.setMimeType(mimetype);
                    String cookies = CookieManager.getInstance().getCookie(url);
                    request.addRequestHeader("cookie", cookies);
                    request.addRequestHeader("User-Agent", userAgent);
                    request.setDescription("Downloading File...");
                    request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
                    request.allowScanningByMediaScanner();
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(
                            Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(
                                    url, contentDisposition, mimetype));
                    DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    dm.enqueue(request);
                    Toast.makeText(getApplicationContext(), "Downloading File", Toast.LENGTH_LONG).show();

                }
            });
        }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        final WebView w= findViewById(R.id.web);
        if (searchtype[position].equals("Google")){
            searchclick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String query = e1.getText().toString();
                    String url ="https://www.google.com/search?q="+query;
                    w.loadUrl(url);
                    w.getSettings().setJavaScriptEnabled(true);
                    w.setWebViewClient(new WebViewClient());
                    e1.setText(query);
                }
            });
            e1.setOnKeyListener(new View.OnKeyListener() {
                public boolean onKey(View v, int keyCode, KeyEvent event) {

                    if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                            (keyCode == KeyEvent.KEYCODE_ENTER)) {
                        String query = e1.getText().toString();
                        String url ="https://www.google.com/search?q="+query;
                        w.loadUrl(url);
                        w.getSettings().setJavaScriptEnabled(true);
                        w.setWebViewClient(new WebViewClient());
                        e1.setText(query);
                    }
                    return false;
                }
            });
        }
        else if (searchtype[position].equals("Yahoo")){
            searchclick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String query = e1.getText().toString();
                    String url ="https://in.search.yahoo.com/search?p="+query;
                    w.loadUrl(url);
                    w.getSettings().setJavaScriptEnabled(true);
                    w.setWebViewClient(new WebViewClient());
                    e1.setText(query);
                }
            });
            e1.setOnKeyListener(new View.OnKeyListener() {
                public boolean onKey(View v, int keyCode, KeyEvent event) {

                    if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                            (keyCode == KeyEvent.KEYCODE_ENTER)) {
                        String query = e1.getText().toString();
                        String url ="https://in.search.yahoo.com/search?p="+query;
                        w.loadUrl(url);
                        w.getSettings().setJavaScriptEnabled(true);
                        w.setWebViewClient(new WebViewClient());
                        e1.setText(query);
                    }
                    return false;
                }
            });
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        final WebView w= findViewById(R.id.web);
        searchclick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String query = e1.getText().toString();
                String url ="https://www.google.com/search?q="+query;
                w.loadUrl(url);
                w.getSettings().setJavaScriptEnabled(true);
                w.setWebViewClient(new WebViewClient());
                e1.setText(url);
            }
        });
        e1.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    String query = e1.getText().toString();
                    String url ="https://www.google.com/search?q="+query;
                    w.loadUrl(url);
                    w.getSettings().setJavaScriptEnabled(true);
                    w.setWebViewClient(new WebViewClient());
                    e1.setText(url);
                }
                return false;
            }
        });
    }
}