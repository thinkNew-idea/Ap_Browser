package com.example.apbrowser;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class free_game extends AppCompatActivity {
    ImageView firstgame, secondgame, thirdgame, Fouthgame,Fivegame,sixgame;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_free_game);
        firstgame = findViewById(R.id.tictac);
        secondgame=findViewById(R.id.Bubble_shooter);
        thirdgame=findViewById(R.id.drop_dunks);
        Fouthgame=findViewById(R.id.chess);
        Fivegame=findViewById(R.id.candy_mahjongg);
        sixgame=findViewById(R.id.brain_booster);


        firstgame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a = "https://playtictactoe.org/";
                Intent i = new Intent(free_game.this, Webviews.class);
                i.putExtra("ur", a);
                startActivity(i);
            }
        });

        secondgame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a = "https://www.shooter-bubble.com/";
                Intent i = new Intent(free_game.this, Webviews.class);
                i.putExtra("ur", a);
                startActivity(i);
            }
        });

        thirdgame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a = "https://odiusfly.com/portfolio/drop_dunks/";
                Intent i = new Intent(free_game.this, Webviews.class);
                i.putExtra("ur", a);
                startActivity(i);
            }
        });
        Fouthgame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a = "https://www.chess.com/play/computer";
                Intent i = new Intent(free_game.this, Webviews.class);
                i.putExtra("ur", a);
                startActivity(i);
            }
        });
        Fivegame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a = "https://www.mahjong.com/game/Mahjongg+Candy";
                Intent i = new Intent(free_game.this, Webviews.class);
                i.putExtra("ur", a);
                startActivity(i);
            }
        });

        sixgame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a = "https://games.washingtonpost.com/games/brain-booster-crossword/";
                Intent i = new Intent(free_game.this, Webviews.class);
                i.putExtra("ur", a);
                startActivity(i);
            }
        });

        final BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        bottomNavigationView.clearAnimation();
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.action_settings:
                        Intent setting = new Intent(getApplicationContext(), setting_page.class);
                        startActivity(setting);
                      overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
                        break;
                    case R.id.backword:
                        Intent i1 = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(i1);
                        overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
                        break;
                    case R.id.action_home:
                        Intent home = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(home);
                        overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
                        break;
                    case R.id.action_download:
                        Intent i=new Intent();
                        i.setAction(DownloadManager.ACTION_VIEW_DOWNLOADS);
                        startActivity(i);
                        overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
                        break;
                    case R.id.forword:
                        menuItem.setCheckable(false);
                        Toast.makeText(getApplicationContext(),"Nothing is to Forword",Toast.LENGTH_LONG).show();
                        break;

                }
                return false;
            }
        });
    }
}